package com.student.controller;

import com.student.dao.StudentDAO;
import com.student.model.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/register")
public class StudentController extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String course = request.getParameter("course");

        try {
            Student student = new Student(name, email, course);
            new StudentDAO().save(student);

            response.setContentType("text/html");
            response.getWriter().println(
                "<h2>Student Registered Successfully!</h2>" +
                "<p>Name: " + name + "</p>" +
                "<p>Email: " + email + "</p>" +
                "<p>Course: " + course + "</p>"
            );
        } catch (Exception e) {
            throw new ServletException("Database error", e);
        }
    }
}
