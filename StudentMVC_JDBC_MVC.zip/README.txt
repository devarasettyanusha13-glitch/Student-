STUDENT MVC + JDBC + MYSQL APPLICATION

Flow:
HTML -> Servlet Controller -> DAO -> JDBC -> MySQL

Requirements:
1. JDK
2. Apache Tomcat
3. MySQL
4. MySQL Connector/J
5. Jakarta Servlet API

Steps:
1. Run database.sql in MySQL.
2. Configure the MySQL username/password in DBConnection.java.
3. Add MySQL Connector/J to the project.
4. Deploy the project on Tomcat.
5. Open index.html through the Tomcat application.
